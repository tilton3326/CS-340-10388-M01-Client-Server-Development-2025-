from pymongo import MongoClient

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """
    def __init__(self, username, password):
        #
        # Connection Variables
        HOST = 'localhost'  
        PORT = 27017
        DB = 'aac'
        COL = 'animals' 
        Auth_DB = 'admin'
        self.client = MongoClient("mongodb://%s:%s@%s:%d/?authSource=%s" % (username, password, HOST, PORT, Auth_DB))
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 
        # Initialize Connection and verify
        try:
            self.client.server_info()  # Test connection
        except Exception as e:
            print(f"Connection failed: {str(e)}")
            raise

    # Create (C in CRUD)
    def create(self, data):
        # validates input is a dictionary
        if not isinstance(data, dict):
            return {"error": "Input must be a dictionary"}
        # checks if data is not empty
        if data:
            try:
                # inserts document into collection
                result = self.collection.insert_one(data)
                # returns True if insertion succeeded, False otherwise
                return True if result.inserted_id else False
            except Exception as e:
                # returns error message if insertion fails
                return {"error": str(e)}
        else:
            # returns error if data is empty
            return {"error": "Nothing to save, because data parameter is empty"}

    # Read (R in CRUD)
    def read(self, data):
        # validates input is a dictionary
        if not isinstance(data, dict):
            return {"error": "Input must be a dictionary"}
        try:
            # checks if query data is not empty
            if data:
                # finds documents matching query
                find_data = self.collection.find(data)
            else:
                # returns all documents if query is empty
                find_data = self.collection.find()
            # Convert to list and handle empty result
            result = [doc for doc in find_data]
            if not result:
                return [{"empty": True}]  # Return a placeholder for empty results
            return result
        except Exception as e:
            # returns error message if query fails
            return {"error": str(e)}
        
    # Update (U in CRUD)
    def update(self, query, data):
        # validates both inputs are dictionaries
        if not isinstance(query, dict) or not isinstance(data, dict):
            return {"error": "Both query and data parameters must be dictionaries"}
        # checks if update data is not empty
        if data:
            try:
                # updates documents matching query
                result = self.collection.update_many(query, {"$set": data})
                # returns number of modified documents
                return result.modified_count
            except Exception as e:
                # returns error message if update fails
                return {"error": str(e)}
        else:
            # returns error if data is empty
            return {"error": "Nothing to save, because data parameter is empty"}
    
    # Delete (D in CRUD)
    def delete(self, data):
        # validates input is a dictionary
        if not isinstance(data, dict):
            return {"error": "Input must be a dictionary"}
        # checks if data is not empty
        if data:
            try:
                # deletes documents matching query
                result = self.collection.delete_many(data)
                # returns number of deleted documents
                return result.deleted_count
            except Exception as e:
                # returns error message if deletion fails
                return {"error": str(e)}
        else:
            # returns error if data is empty
            return {"error": "Nothing to save, because data parameter is empty"}